# Query-Free Adversarial Attacks on Stable Diffusion: reproduction package

This package contains the report **Query-Free Adversarial Attacks on Stable
Diffusion: A Small-Scale Reproduction** and the code and measured results behind
it. It reproduces, at reduced scale, the untargeted and targeted attacks of
Zhuang, Zhang and Liu, *A Pilot Study of Query-Free Adversarial Attack against
Stable Diffusion* (CVPR Workshops 2023, arXiv:2303.16378).

## Contents

- `QF_Attack_Report.pdf`, `QF_Attack_Report.md`: the report.
- `qf_attack.py`: the attack and image-generation implementation.
- `requirements-colab.txt`: dependency pins.
- `qf_results/`: the measured run (suffixes, cosines, masks, images, grids,
  manifest and software provenance).
- `qf_results/embedding_analysis/`: the embedding and detector analysis
  (metrics, figures, detector scores).
- `tools/`: the scripts that produce the analysis and the report.

## Reproduce the measured run

```bash
python qf_attack.py --profile demo
python tools/validate_results.py
```

## Rebuild the analysis and the report

```bash
python tools/embedding_analysis.py     # encoder metrics (CLIP text encoder)
python tools/plot_embeddings.py        # Figures 1-6
python tools/detector_scoring.py       # OWL-ViT object detection, Section 4.5
python tools/plot_detector.py          # Figure 7
python tools/build_paper.py            # QF_Attack_Report.pdf and .md
```

`embedding_analysis.py` and `detector_scoring.py` read the images already in
`qf_results/`; the detector step downloads OWL-ViT (google/owlvit-base-patch32).
The encoder steps run on CPU or Apple MPS; generating images needs a GPU.

## Scope

This is a method reproduction on two prompts with one image seed, not an exact
replication of the paper's Table 1. PGD is not implemented. CLIP cosine is not an
object-presence label; see the report's limitations. The run makes zero diffusion
calls during the suffix search.

Reference implementation: https://github.com/OPTML-Group/QF-Attack
